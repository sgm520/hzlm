<?php

return array (
  0 => 
  array (
    'name' => 'developerTips',
    'title' => '开发者提示',
    'type' => 'radio',
    'content' => 
    array (
      0 => '隐藏',
      1 => '显示',
    ),
    'value' => '1',
    'rule' => 'required',
    'msg' => '对开发者显示插件帮助信息，可在项目交付后隐藏',
    'tip' => '对开发者显示插件帮助信息，可在项目交付后隐藏',
    'ok' => '',
    'extend' => '',
  ),
);
