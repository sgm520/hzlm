<?php
/**
 * Author: DOUBLE Y
 * Date: 2019/2/25 16:21
 * Email: 731633799@qq.com
 */

namespace addons\voicenotice;


use think\Addons;
use think\Config;
use think\View;

/**
 * 插件
 */
class Voicenotice extends Addons
{
    /**
     * 插件安装方法
     * @return bool
     */
    public function install()
    {
        return true;
    }

    /**
     * 插件卸载方法
     * @return bool
     */
    public function uninstall()
    {
        return true;
    }

    public function run()
    {
        return true;
    }

    /**
     * 插件启用方法
     * @return bool
     */
    public function enable()
    {
        return true;
    }

    /**
     * 插件禁用方法
     * @return bool
     */
    public function disable()
    {
        return true;
    }


    public function actionBegin()
    {
        $conf = $this->getConfig();
        $view = View::instance(Config::get('template'), Config::get('view_replace_str'));
        $voiceNotice['delay'] = (isset($conf["delay"]) && is_numeric($conf["delay"]))?$conf["delay"]*1000:4000;
        if(isset($view->config)){
            $voiceNotice && $view->config = array_merge($view->config ? $view->config : [], compact('voiceNotice'));
        }
    }
}
