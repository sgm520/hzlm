
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


--
-- 表的结构 `__PREFIX__csmtable_xlstask`
--
CREATE TABLE IF NOT EXISTS `__PREFIX__csmtable_xlstask` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `admin_id` int(10) unsigned DEFAULT 0 COMMENT '管理员',
  `filesource` varchar(200) DEFAULT NULL COMMENT '文件来源标记',
  `filename` varchar(500) DEFAULT NULL COMMENT '文件名',
  `param` text DEFAULT NULL COMMENT '参数',
  `progress` int(10) unsigned DEFAULT 0 COMMENT '下载进度',
  `status` enum('normal','hidden') DEFAULT 'normal' COMMENT '状态',
  `createtime` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '创建时间',
  `updatetime` int(10) unsigned DEFAULT 0 COMMENT '更新时间',
  `iserror` enum('Y','N') DEFAULT 'N' COMMENT '是否处理错误',
  `errormsg` text DEFAULT NULL COMMENT '错误信息',
  `b1` varchar(100) DEFAULT NULL COMMENT '备用字段1',
  `b2` varchar(100) DEFAULT NULL COMMENT '备用字段2',
  `b3` varchar(100) DEFAULT NULL COMMENT '备用字段3',
  `b4` varchar(100) DEFAULT NULL COMMENT '备用字段4',
  `b5` varchar(100) DEFAULT NULL COMMENT '备用字段5',
  `b6` varchar(100) DEFAULT NULL COMMENT '备用字段6',
  `b7` varchar(100) DEFAULT NULL COMMENT '备用字段7',
  `b8` varchar(100) DEFAULT NULL COMMENT '备用字段8',
  `b9` varchar(100) DEFAULT NULL COMMENT '备用字段9',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=utf8 COMMENT='Excel下载任务表'
;


COMMIT;