<?php

namespace addons\csmtable\controller;

use think\addons\Controller;

class Index extends Controller
{
    /**
     * http://127.0.0.1/fastadmin_plugin_csmmeet/public/addons/csmtable/index/index
     */
    public function index()
    {
        $this->error("当前插件3暂无前台页面",null,null,300);
    }
    
    public function test(){
        $control = new \app\admin\controller\fa\Test();
        return $control->index();
    }
    

}
