<?php
namespace addons\csmtable\library;

use fast\Random;
use think\Session;

class CsmTableUtils
{

    /**
     *
     * @usaged
     *        var_dump(CsmTableUtils::getInstanceAndMethod("fa/test"));
     *        var_dump(CsmTableUtils::getInstanceAndMethod("fa/test/test"));
     *        array (size=2)
     *          0 => string '\app\admin\controller\fa\Test' (length=29)
     *          1 => string 'index' (length=5)
     *
     *        var_dump(CsmTableUtils::getInstanceAndMethod("category"));
     *        var_dump(CsmTableUtils::getInstanceAndMethod("category/test"));
     *        array (size=2)
     *          0 => string '\app\admin\controller\Category' (length=30)
     *          1 => string 'index' (length=5)
     */
    public static function getInstanceAndMethod(&$url)
    {
        $im = static::_isClassExists($url);
        if ($im == null) {
            $im = static::_isClassExists($url . "/index");
        }
        if ($im == null) {
            $im = static::_isClassExists($url . "index");
        }
        return $im;
    }

    private static function _isClassExists($url)
    {
        $sr = null;
        $clsname = "\\app\\admin\\controller";
        $patharr = explode("/", $url);
        foreach ($patharr as $k => $v) {
            if ($k == (count($patharr) - 2)) {
                $clsname .= "\\" . ucfirst($v);
                break;
            } else {
                $clsname .= "\\" . $v;
            }
        }
        $b = class_exists($clsname);
        if ($b === true) {
            $methodname = $patharr[count($patharr) - 1];
            if (count($patharr) == 1) {
                $methodname = 'index';
            }
            $sr = [
                $clsname,
                $methodname
            ];
        }
        return $sr;
    }

    public static function directLogin($username, $keeptime = 86400)
    {
        $dao = new \app\admin\model\Admin();
        $admin = $dao->where('username', '=', $username)->find();
        if ($admin == null) {
            echo "系统中找不到帐号:{$username},无法执行登录!";
            die();
        }

        // Copy from app\admin\library\Auth#login
        $admin->loginfailure = 0;
        $admin->logintime = time();
        $admin->loginip = request()->ip();
        $admin->token = Random::uuid();
        $admin->save();
        Session::set("admin", $admin->toArray());
    }
    
    

    
    
}
