<?php
namespace addons\csmtable\library;

use think\Request;

class CsmRequest extends Request
{
    
    private $datas = [];
    
    private $methoddatas = [];
    
    protected static $instance;
    
    public function _initialize()
    {
        parent::_initialize();
    }
    
    public static function instance($options = [])
    {
        if (is_null(self::$instance)) {
            self::$instance = new CsmRequest($options);
        }
        self::$instance->clear();
        return self::$instance;
    }
    
    public function clear()
    {
        $this->datas = [];
        $this->methoddatas = [];
    }
    
    protected function __construct($options = [])
    {
        parent::__construct($options);
    }
    
    public function setMethodReturn($methodname, $value)
    {
        $this->methoddatas[$methodname] = $value;
    }
    
    public function isAjax($ajax = false)
    {
        $methodname = 'isAjax';
        if (isset($this->methoddatas[$methodname])) {
            return $this->methoddatas[$methodname];
        }
        return parent::isAjax($ajax);
    }
    
    public function set($name, $value)
    {
        $this->datas[$name] = $value;
    }
    
    public function get($name = '', $default = null, $filter = '')
    {
        if(is_array($name)){
            foreach($name as $kk=>$vv){
                static::p($kk.'='.$vv);
                return $vv;
            }
        }
        
        if (isset($this->datas[$name])) {
            static::p($name.'='.$this->datas[$name]);
            return $this->datas[$name];
        }
        return parent::get($name, $default, $filter);
    }
    
    public static function p($str)
    {
        trace($str);
        //echo($str."<BR>");
    }
}
