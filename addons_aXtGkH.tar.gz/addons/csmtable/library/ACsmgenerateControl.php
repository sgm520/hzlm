<?php
namespace addons\csmtable\library;

use app\common\controller\Backend;
use think\App;

abstract class ACsmgenerateControl extends Backend
{

    protected $noNeedLogin = [
        '*'
    ];

    protected $noNeedRight = [
        '*'
    ];

    protected $xlstaskdao = null;

    // config 配置
    protected $excelmaxrecoredcount = null;

    protected $privatehosturl = null;

    protected $adminaccount = null;

    protected $controlpagesize = null;
    
    protected $uploadtmppath = RUNTIME_PATH . 'temp' . DS;

    public function _initialize()
    {
        parent::_initialize();
        $this->xlstaskdao = new \app\admin\model\csmtable\Xlstask();
        $config = get_addon_config("csmtable");
        $this->excelmaxrecoredcount = (int)$config["excelmaxrecoredcount"];
        $this->privatehosturl = $config["privatehosturl"];
        $this->adminaccount = $config["adminaccount"];
        $this->controlpagesize = $config["controlpagesize"];
    }
    // 获取记录数
    public function getDataRecordTotal(&$params)
    {
        $controlData = $this->callRemoteControl($params, 0, 1);
        return $controlData->getData()['total'];
    }

    public function getXlstaskParams($id)
    {
        $xlstaskrow = $this->xlstaskdao->where('id', '=', $id)->find();
        if ($xlstaskrow == null) {
            return;
        }
        return json_decode($xlstaskrow->param, true);
    }

    /**
     * 调用Control的查询方法
     */
    public function callRemoteControl(&$params, $offset, $limit)
    {
        $classname = str_replace('/', '\\', $this->getParamValue($params, 'csmtable_classname'));
        $methodname = $this->getParamValue($params, 'csmtable_methodname');
        // echo "--------------".$classname;
        $request = CsmRequest::instance();
        $instance = new $classname($request);
        $request->set('search', $this->getParamValue($params, 'search'));
        $request->set('filter', $this->getParamValue($params, 'filter'));
        $request->set('op', $this->getParamValue($params, 'op'));
        $request->set('sort', $this->getParamValue($params, 'sort'));
        $request->set('order', $this->getParamValue($params, 'order'));
        $request->set("offset", $offset);
        $request->set("offset/d", $offset);//v2.1.8 修复在1.2.0.20201008_beta版本下导出数据记录数错误的问题
        $request->set('limit', $limit);
        $request->set('limit/d', $limit);//v2.1.8 修复在1.2.0.20201008_beta版本下导出数据记录数错误的问题
        $request->setMethodReturn("isAjax", true);

        return App::invokeMethod([
            $instance,
            $methodname
        ], null);
    }

    public function getParamValue(&$params, $key, $defaultvalue = null)
    {
        $sr = null;
        if (isset($params[$key])) {
            $sr = $params[$key];
        }
        $sr = ($sr == null) ? $defaultvalue : $sr;
        return $sr;
    }

    public static function p($str)
    {
        trace($str); 
        //echo($str."<BR>");
    }
    
}