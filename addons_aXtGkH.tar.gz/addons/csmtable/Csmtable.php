<?php
namespace addons\csmtable;

use think\Addons;
use think\Request;
use app\admin\library\Auth;
use app\common\library\Menu;
use addons\csmtable\library\CsmUtils;
use GuzzleHttp\Handler\CurlMultiHandler;
use GuzzleHttp\HandlerStack;
use GuzzleHttp\Client;
use Psr\Http\Message\ResponseInterface;

/**
 * 插件
 */
class Csmtable extends Addons
{

    /**
     * 插件安装方法
     *
     * @return bool
     */
    public function install()
    {
        $menu = [
            [
                'name' => 'csmtable',
                'title' => 'Table功能增强',
                'sublist' => [
                    [
                        'name' => 'csmtable/test',
                        'title' => '使用示例',
                        'icon' => 'fa fa-meetup',
                        'sublist' => [
                            [
                                'name' => 'csmtable/test/index',
                                'title' => '查询'
                            ],
                            [
                                'name' => 'csmtable/test/recyclebin',
                                'title' => '回收站'
                            ],
                            [
                                'name' => 'csmtable/test/add',
                                'title' => '添加'
                            ],
                            [
                                'name' => 'csmtable/test/edit',
                                'title' => '修改'
                            ],
                            [
                                'name' => 'csmtable/test/del',
                                'title' => '删除'
                            ],
                            [
                                'name' => 'csmtable/test/destroy',
                                'title' => '真实删除'
                            ],
                            [
                                'name' => 'csmtable/test/restore',
                                'title' => '还原'
                            ],
                            [
                                'name' => 'csmtable/test/multi',
                                'title' => '批量更新'
                            ],
                            [
                                'name' => 'csmtable/test/import',
                                'title' => '导入'
                            ]
                        ]
                    ],
                    [
                        'name' => 'csmtable/xlstask',
                        'title' => '下载任务',
                        'icon' => 'fa fa-meetup',
                        'sublist' => [
                            [
                                'name' => 'csmtable/xlstask/index',
                                'title' => '查询'
                            ],
                            [
                                'name' => 'csmtable/xlstask/add',
                                'title' => '添加'
                            ],
                            [
                                'name' => 'csmtable/xlstask/edit',
                                'title' => '修改'
                            ],
                            [
                                'name' => 'csmtable/xlstask/del',
                                'title' => '删除'
                            ],
                            [
                                'name' => 'csmtable/csmgeneratesub/index',
                                'title' => '重新执行'
                            ],
                        ]
                    ]
                ]
            ]
        ];
        Menu::create($menu);
        return true;
    }

    /**
     * 插件卸载方法
     *
     * @return bool
     */
    public function uninstall()
    {
        Menu::delete("csmtable");
        return true;
    }

    /**
     * 插件启用方法
     *
     * @return bool
     */
    public function enable()
    {
        Menu::enable("csmtable");
        return true;
    }

    /**
     * 插件禁用方法
     *
     * @return bool
     */
    public function disable()
    {
        Menu::disable("csmtable");
        return true;
    }

    public function actionBegin($call)
    {
        $request = Request::instance();

        if (true) {
            // 判断是否安装了插件:表格无刷新行内编辑
            $path = $request->path();
            if ($path == 'csmtable/test') {
                $editable = get_addon_info('editable');
                if (! $editable || ! $editable['state']) {
                    CsmUtils::error("为更好的演示本功能，请安装【表格无刷新行内编辑】插件", null, null, 60);
                }
            }
        }
        if (true) {
            // 异步下载用

            $method = $request->request('csmtable_method');
            $filesource = $request->request('csmtable_filesource');
            if ($method == 'download_excel') {
                set_time_limit(0);
                $auth = Auth::instance();

                $dao = new \app\admin\model\csmtable\Xlstask();

                // 限制下载
                if (true) {
                    $row = $dao->where("admin_id", "=", $auth->id)
                        ->where("progress", "<", "100")
                        ->where("createtime", ">", time() - 1800)
                        ->where("iserror", "<>", "Y")
                        ->find();
                    // echo $dao->getLastSql();
                    if ($row) {
                        CsmUtils::error("当前有下载任务，请任务结束后再尝试下载。");
                    }
                }

                // 生成任务记录
                $dao->where("admin_id", "=", $auth->id)
                    ->where("filesource", '=', $filesource)
                    ->where("status", "=", "normal")
                    ->update([
                    "status" => "hidden"
                ]);

                // 触发异步生成Excel任务
                $classname = get_class($call[0]);
                $getparams = [
                    'search' => $request->request('search'),
                    'filter' => $request->request('filter'),
                    'op' => $request->request('op'),
                    'sort' => $request->request('sort'),
                    'order' => $request->request('order'),
                    'offset' => $request->request('offset'),
                    'limit' => $request->request('limit'),
                    'csmtable_classname' => str_replace('\\', '/', $classname),
                    'csmtable_methodname' => 'index',
                    'csmtable_columns' => $request->request('csmtable_columns')
                ];

                $param = [
                    'admin_id' => $auth->id,
                    'filesource' => $filesource,
                    'param' => json_encode($getparams),
                    'createtime' => time()
                ];
                $dao->create($param);
                $id = $dao->getLastInsID();

                $config = get_addon_config("csmtable");
                $privatehosturl = $config["privatehosturl"];
                
                //v2.1.8 修复如果获取不到$_SERVER["REQUEST_SCHEME"],下载卡在10%的问题
                if (($privatehosturl == null || $privatehosturl == '') && ($_SERVER["REQUEST_SCHEME"]==null || $_SERVER["REQUEST_SCHEME"]=='')) {
                    CsmUtils::error("请配置参数[本地服务器地址],具体配置位置为:插件管理-FastAdmin表格优化增强-本地服务器地址");
                }
                
                
                // $url = "http://127.0.0.1/fastadmin_plugin_csmmeet/public/q3HJDu2RgE.php/csmtable/cligenerateexcel/index";
                $privatehosturl = ($privatehosturl != null && $privatehosturl != '') ? $privatehosturl : ($_SERVER["REQUEST_SCHEME"] . "://" . $_SERVER["SERVER_NAME"]);
                
                
                $url = $privatehosturl . $request->baseFile() . '/csmtable/csmgenerate/index?id=' . $id;
                $this->callremote2($url);
            }
        }
    }

    private function callremote2($url)
    {
        // \fast\Http::sendAsyncRequest($url);
        \fast\Http::sendRequest($url);
    }
}
