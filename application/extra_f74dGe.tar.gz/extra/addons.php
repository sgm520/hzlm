<?php

return [
    'autoload' => false,
    'hooks' => [
        'app_init' => [
            'alioss',
        ],
        'upload_config_init' => [
            'alioss',
        ],
        'upload_delete' => [
            'alioss',
        ],
        'action_begin' => [
            'csmtable',
            'voicenotice',
        ],
        'sms_send' => [
            'smsbao',
        ],
        'sms_notice' => [
            'smsbao',
        ],
        'sms_check' => [
            'smsbao',
        ],
        'run' => [
            'voicenotice',
        ],
    ],
    'route' => [],
    'priority' => [],
    'domain' => '',
];
