<?php

return array (
  'name' => '蚂蚁汇推',
  'beian' => '蜀ICP备2021026505号-1',
  'version' => '2.0.12',
  'timezone' => 'Asia/Shanghai',
  'fixedpage' => 'dashboard',
  'categorytype' => 
  array (
    'slt' => '示例图',
  ),
  'configgroup' => 
  array (
    'basic' => '基础配置',
    'email' => '邮件配置',
    'dictionary' => '字典配置',
    'user' => '会员配置',
    'example' => '示例分组',
  ),
  'mail_type' => '1',
  'mail_from' => '10000@qq.com',
  'WechatGroupImg' => '/uploads/20211118/82885556e20b667195e95a170ec7610c.png',
  'InviteImg' => '/uploads/20211106/6c58af1635219b61947f980785e4999f.png',
  'WechatPublic' => '/uploads/20211106/e1dd27b7d9962a3194afa36f935fa818.jpg',
  'ContactCustomerImg' => '/uploads/20211106/f30a9028bd8e9e964a8e10b8677c5d6d.jpg',
  'ios_download_link' => 'http://xz.tvpdd.com/',
  'img_url' => 'http://hzlm.ttaqkf.com/',
  'h5_url' => 'http://h5.tvpdd.com',
  'kefu_url' => 'http://ltkf.tvpdd.com/kefu/61b0b344114fc',
  'android_download_url' => 'http://xz.tvpdd.com/',
  'password' => '',
  'visit_url' => 'http://h5.tvpdd.com/#/pages/user/index?s_id=',
);
